﻿using System.Web.UI;

namespace REAL_ESTATE_PORTAL.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}