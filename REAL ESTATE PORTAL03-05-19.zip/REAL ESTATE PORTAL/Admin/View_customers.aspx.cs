﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using REAL_ESTATE_PORTAL.Class;
using System.Data;
using System.Data.SqlClient;

namespace REAL_ESTATE_PORTAL.Admin
{
    public partial class View_customers : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            REAL_ESTATE_PORTAL.Class.View_customers viewobj = new REAL_ESTATE_PORTAL.Class.View_customers();

            DataTable dtReg = new DataTable();
            dtReg = viewobj.ExecuteSelectQueries();

            if (dtReg.Rows.Count > 0)
            {
                GridView1.DataSource = dtReg;
                GridView1 .DataBind();
            }
        }

    }
}


































