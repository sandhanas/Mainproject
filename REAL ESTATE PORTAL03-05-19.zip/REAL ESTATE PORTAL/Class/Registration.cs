﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;


namespace REAL_ESTATE_PORTAL.Class
{
    public class Registration
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function

            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        private string name;
        private string address;
        private string state;
        private string district;
        private string mobile;
        private string email;
        private string password;
        private string retypepassword;
        private string profile;

        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public string Address
        {
            get
            {
                return address;
            }

            set
            {
                address = value;
            }
        }

        public string State
        {
            get
            {
                return state;
            }

            set
            {
                state = value;
            }
        }

        public string District
        {
            get
            {
                return district;
            }

            set
            {
                district = value;
            }
        }

        public string Mobile
        {
            get
            {
                return mobile;
            }

            set
            {
                mobile = value;
            }
        }

        public string Email
        {
            get
            {
                return email;
            }

            set
            {
                email = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }

        public string Retypepassword
        {
            get
            {
                return retypepassword;
            }

            set
            {
                retypepassword = value;
            }
        }

        public string Profile
        {
            get
            {
                return profile;
            }

            set
            {
                profile = value;
            }
        }


        public void registration()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(Rid) from Registration", con);
            int Rid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                Rid = (int)cMax;
                Rid++;
            }
            else
            {
                Rid = 1;
            }
            string qry = "insert into Registration values('" + Rid + "',@Rname,@Raddress,@Rstate,@Rdistrict,@Rmobile,@Remail,@Rpassword,@Rretypepass,@Rprofile)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@Rname", name);
            cmd.Parameters.AddWithValue("@Raddress", address);
            cmd.Parameters.AddWithValue("@Rstate", state);
            cmd.Parameters.AddWithValue("@Rdistrict", district);
            cmd.Parameters.AddWithValue("@Rmobile", mobile);
            cmd.Parameters.AddWithValue("@Remail", email);
            cmd.Parameters.AddWithValue("@Rpassword", password);
            cmd.Parameters.AddWithValue("@Rretypepass", retypepassword);
            cmd.Parameters.AddWithValue("@Rprofile", profile);
            cmd.ExecuteNonQuery();
        }

        public void insertlogin()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("select max(Lid) from Login ", con);
            int login_no;
     
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                login_no = (int)cMax;
                login_no++;
            }
            else
            {
                login_no = 1;
            }
            string qry = "insert into Login values('" + login_no + "',@username,@password)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@username", email);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.ExecuteNonQuery();
        }

    }
}