﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace REAL_ESTATE_PORTAL.Class
{
    public class Sellershome
    {
    }
}