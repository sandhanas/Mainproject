﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI;

namespace REAL_ESTATE_PORTAL.Class
{
    public class User_profile
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

    public void Executequires(string Query_)
        {

            SqlCommand cmd = new SqlCommand(Query_,con);
            cmd.ExecuteNonQuery();
 
        }
        private int userid;

             public int Userid
         
        {
            get
            {
                return userid;
            }

            set
            {
                userid = value;
            }
        }

        
        public DataTable ExecuteSelectQueries()
        {
            OpenConection();

            String qry = "select * from Registration ";


            SqlCommand cmd = new SqlCommand(qry, con);


            cmd.ExecuteNonQuery();



            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dtReg1 = new DataTable();



            da.Fill(dtReg);

            CloseConnection();
            return dtReg;

        }




        public DataTable disply()
        {
            DataTable dtReg = new DataTable();
            OpenConection();

            String qry = "select * from Registration where Rid=@userid";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@userid",userid);
            cmd.ExecuteNonQuery();
            CloseConnection();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);

            CloseConnection();
            return dtReg;



        }


    }

}