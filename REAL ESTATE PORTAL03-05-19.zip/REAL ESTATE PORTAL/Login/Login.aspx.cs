﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using REAL_ESTATE_PORTAL.Class;
using System.Data;

namespace REAL_ESTATE_PORTAL.Login
{
    
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataTable dtReg = new DataTable();
            REAL_ESTATE_PORTAL.Class.Login objlog = new Class.Login();
            objlog.Username = txtlusername.Text;
            objlog.Password = txtlpass.Text;
            dtReg = objlog.Executeselectquries();
            if (objlog.Username == "admin" && objlog.Password == "admin")
            {
                Session["admin"] = txtlusername.Text;
                Response.Redirect("~/Admin/Admin_home.aspx");
            }
            else if (dtReg.Rows.Count > 0)
            {
                Session["Rid"] = Convert.ToString(dtReg.Rows[0][0]);

               lbl_mes.Text = " Sucess.";
                //lbl_mes.Text = Session["Rid"].ToString();
                Response.Redirect("~/User/Userhome.aspx");
            }
            else
            {
                lbl_mes.Text = " Incorrect username or password";
            }

            //}

            //if (dtReg.Rows.Count > 0)
            //{
            //    lbl_mes.Text = "Successful Login";
            //}
            //else
            //{
            //    lbl_mes.Text = "Invalid User";
            //}

        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }
    }
}