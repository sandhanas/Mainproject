﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using REAL_ESTATE_PORTAL.Class;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace REAL_ESTATE_PORTAL.Registration
{
    public partial class Registration : System.Web.UI.Page
    {
        
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
          //  Registration reg = new Registration();
            REAL_ESTATE_PORTAL.Class.Registration objReg = new Class.Registration();
            objReg.Name = txtname.Text;
            objReg.Address = txtaddress.Text;
            objReg.State = dpdstate.SelectedItem.Text;
            objReg.District = dpdstate.SelectedItem.Text;
            objReg.Mobile = txtmob.Text;
            objReg.Email = txtemail.Text;
            objReg.Password = txtpass.Text;
            objReg.Retypepassword = txtretypepass.Text;
            string filename = Path.GetFileName(filepic.PostedFile.FileName);
            string ext = Path.GetExtension(filename);
            if (ext.ToLower() == ".jpg" || ext.ToLower() == ".bmp" || ext.ToLower() == ".png" || ext.ToLower() == ".jpeg")
            {
                string src = Server.MapPath("~/photo") + "\\" + txtname.Text + ".JPG";
                filepic.PostedFile.SaveAs(src);
                string picpath = "~/photo/" + txtname.Text + ".JPG";
                objReg.Profile = picpath;
            }
            objReg.registration();
            objReg.insertlogin();
           Response.Redirect("Login.aspx");

        }
    }
}