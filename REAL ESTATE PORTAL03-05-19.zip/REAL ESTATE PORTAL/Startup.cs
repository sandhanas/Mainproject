﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(REAL_ESTATE_PORTAL.Startup))]
namespace REAL_ESTATE_PORTAL
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
