﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using REAL_ESTATE_PORTAL.Class;


namespace REAL_ESTATE_PORTAL.User
{
    public partial class User_profile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String userid = Session["Rid"].ToString();
            Response.Write(userid);
            Loaddata();
        }
        public void Loaddata()
        {
            DataTable dtReg = new DataTable();
            REAL_ESTATE_PORTAL.Class.User_profile objprofil = new Class.User_profile();
            objprofil.Userid= Convert.ToInt32(Session["Rid"]);
            dtReg =objprofil.disply();
            if (dtReg.Rows.Count > 0)
            {
                txtpname.Text = Convert.ToString(dtReg.Rows[0]["Rname"]);
                txtpaddress.Text = Convert.ToString(dtReg.Rows[0]["Raddress"]);
                txtpstate.Text = Convert.ToString(dtReg.Rows[0]["Rstate"]);
                txtpdistrict.Text = Convert.ToString(dtReg.Rows[0]["Rdistrict"]);
                txtpmobile.Text = Convert.ToString(dtReg.Rows[0]["Rmobile"]);
                txtpemail.Text = Convert.ToString(dtReg.Rows[0]["Remail"]);
            }
        }



    }
}